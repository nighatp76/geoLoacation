﻿#pragma once

#include <collection.h>
#include <ppltasks.h>
