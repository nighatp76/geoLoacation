CREATE TABLE IF NOT EXISTS allchannel(id INTEGER PRIMARY KEY AUTOINCREMENT,channelid TEXT,channelName TEXT,channelDescription TEXT,channelimagePath TEXT);
